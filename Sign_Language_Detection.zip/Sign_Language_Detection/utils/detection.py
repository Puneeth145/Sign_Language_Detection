import numpy as np
import tensorflow as tf
import cv2
from utils.preprocess import preprocess_image
from utils.time_window import within_time_window
import pandas as pd
import datetime
import os
model=tf.keras.models.load_model('models/sign_language_model.h5')
labels=['A','B','C','D','E']

def detect_sign(image):
    if not within_time_window():
        return 'Detection not allowed outside time window',0
    preprocessed_image=preprocess_image(image)
    prediction=model.predict(preprocessed_image)
    detected_sign=labels[np.argmax(prediction)]
    confidence=np.max(prediction)
    log_to_csv(detected_sign,confidence)
    return detected_sign,confidence

def log_to_csv(sign,confidence):
    now=datetime.datetime.now()
    data={'Sign':[sign],'Confidence':[confidence],'Timestamp':[now]}
    df=pd.DataFrame(data)
    if not os.path.exists('attendance.csv'):
        df.to_csv('attendance.csv',index=False)
    else:
        df.to_csv('attendance.csv',mode='a',header=False,index=False)

def process_image(file_path):
    image=cv2.imread(file_path)
    detected_sign,confidence=detect_sign(image)
    print(f'Detected: {detected_sign} (Confidence: {confidence:.2f})')

def process_video():
    cap=cv2.VideoCapture(0)
    while within_time_window():
        ret,frame=cap.read()
        if not ret:
            break
        detected_sign,confidence=detect_sign(frame)
        frame=cv2.putText(frame,f'{detected_sign}: {confidence:.2f}',(50,50),cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2,cv2.LINE_AA)
        cv2.imshow('Video',frame)
        if cv2.waitKey(1)&0xFF==ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__=="__main__":
    pass
    # process_image('path_to_image.jpg')
    # process_video()