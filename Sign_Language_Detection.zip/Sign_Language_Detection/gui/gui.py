import tkinter as tk
from tkinter import filedialog,messagebox
from tkinter import PhotoImage
from PIL import Image,ImageTk
import cv2
import numpy as np
import tensorflow as tf
import datetime
import pandas as pd
import os
from utils.preprocess import preprocess_image
from utils.time_window import within_time_window

model=tf.keras.models.load_model('models/sign_language_model.h5')
labels=['A','B','C','D','E']
window=tk.Tk()
window.title('Sign Language Detection')
window.geometry('800x600')
window.configure(bg='lightgray')
logo=Image.open('gui/assets/logo.png').resize((150,150))
logo_img=ImageTk.PhotoImage(logo)
upload_icon=Image.open('gui/assets/upload_icon.png').resize((40,40))
upload_icon_img=ImageTk.PhotoImage(upload_icon)
video_icon=Image.open('gui/assets/video_icon.png').resize((40,40))
video_icon_img=ImageTk.PhotoImage(video_icon)
result_icon=Image.open('gui/assets/result_icon.png').resize((50,50))
result_icon_img=ImageTk.PhotoImage(result_icon)
logo_label=tk.Label(window,image=logo_img,bg='lightgray')
logo_label.pack(pady=10)
info_label=tk.Label(window,text='Upload an Image or Start Video Detection',font=('Arial',14),bg='lightgray')
info_label.pack(pady=10)
upload_button=tk.Button(window,text='Upload Image',image=upload_icon_img,compound=tk.LEFT,command=lambda:upload_image(),bg='white',font=('Arial',12))
upload_button.pack(pady=5)
video_button=tk.Button(window,text='Start Video',image=video_icon_img,compound=tk.LEFT,command=lambda:start_video(),bg='white',font=('Arial',12))
video_button.pack(pady=5)
result_label=tk.Label(window,text='',font=('Arial',16),bg='lightgray')
result_label.pack(pady=10)
image_label=tk.Label(window)
image_label.pack(pady=10)

def preprocess_image(image):
    image=cv2.resize(image,(64,64))
    image=image.astype('float32')/255
    image=np.expand_dims(image,axis=0)
    return image

def detect_sign(image):
    if not within_time_window():
        messagebox.showinfo('Info','Detection allowed only between 6 PM and 10 PM')
        return
    preprocessed_image=preprocess_image(image)
    prediction=model.predict(preprocessed_image)
    detected_sign=labels[np.argmax(prediction)]
    confidence=np.max(prediction)
    log_to_csv(detected_sign,confidence)
    return detected_sign,confidence

def log_to_csv(sign,confidence):
    now=datetime.datetime.now()
    data={'Sign':[sign],'Confidence':[confidence],'Timestamp':[now]}
    df=pd.DataFrame(data)
    if not os.path.exists('attendance.csv'):
        df.to_csv('attendance.csv',index=False)
    else:
        df.to_csv('attendance.csv',mode='a',header=False,index=False)

def upload_image():
    file_path=filedialog.askopenfilename()
    if file_path:
        image=cv2.imread(file_path)
        detected_sign,confidence=detect_sign(image)
        display_image=Image.open(file_path)
        display_image=display_image.resize((400,400))
        photo=ImageTk.PhotoImage(display_image)
        image_label.config(image=photo)
        image_label.image=photo
        result_label.config(text=f'Detected: {detected_sign} (Confidence: {confidence:.2f})',image=result_icon_img)

def start_video():
    cap=cv2.VideoCapture(0)
    while within_time_window():
        ret,frame=cap.read()
        if not ret:
            break
        detected_sign,confidence=detect_sign(frame)
        frame=cv2.putText(frame,f'{detected_sign}: {confidence:.2f}',(50,50),cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2,cv2.LINE_AA)
        cv2.imshow('Video',frame)
        if cv2.waitKey(1)&0xFF==ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

window.mainloop()
